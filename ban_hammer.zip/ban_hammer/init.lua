-----------------------------------------------------------------------------------------------
local title = "Ban Hammer"
local version = "0.2.1"
local mname = "ban_hammer"
-----------------------------------------------------------------------------------------------
dofile(minetest.get_modpath("ban_hammer").."/settings.txt")
-----------------------------------------------------------------------------------------------

local mode_text = {
	{"Ban punched player."},
	{"Kick punched player."},
	{"Remove shout privilege of punched player."},
	{"Remove fly privilege of punched player."},
	{"Remove noclip privilege of punched player."},
}

local function ban_hammer_setmode(user, itemstack, mode, keys)
	local puncher = user:get_player_name()
	if keys["sneak"] == false and mode == 0 then
		minetest.chat_send_player(puncher, "Hold shift and use to change ban hammer modes.")
		return 
	end
	if keys["sneak"] == true then
		mode = mode + 1
		if mode == 6 then 
			mode = 1
		end
		minetest.chat_send_player(puncher, "Ban hammer mode : "..mode.." - "..mode_text[mode][1] )
	end
	itemstack:set_name("ban_hammer:hammer"..mode)
	itemstack:set_metadata(mode)
	return itemstack, mode
end

local function ban_hammer_handler(itemstack, user, pointed_thing, mode)
	local keys = user:get_player_control()
	ban_hammer_setmode(user, itemstack, mode, keys)
	if pointed_thing.type ~= "object" then
		return
	end
	if not pointed_thing.ref:is_player() then
		return
	end
	local puncher = user:get_player_name()
	local puncher_privs = minetest.get_player_privs(puncher)
	if (puncher_privs["ban"] == false) then
		return
	end
	local punched_player = pointed_thing.ref:get_player_name()
	local punched_player_privs = minetest.get_player_privs(punched_player)
	if mode == 1 then
		if SEND_MESSAGE_TO_ALL == true then
			minetest.chat_send_all("The ban hammer has struck, wielded by "..puncher..", banning "..punched_player.." from the server.")
		end
		minetest.log("action", puncher .. " bans " .. punched_player .. ".")
		minetest.ban_player(punched_player)
	elseif mode == 2 then
		if SEND_MESSAGE_TO_ALL == true then
			minetest.chat_send_all("The ban hammer has struck, wielded by "..puncher..", kicking "..punched_player.." from the server.")
		end
		minetest.log("action", puncher .. " kicked " .. punched_player)
		minetest.kick_player(punched_player)
	elseif mode == 3 then
		punched_player_privs["shout"] = nil
		minetest.set_player_privs(punched_player, punched_player_privs)
		minetest.log(puncher..' revoked (shout) privileges from '..punched_player)
		if SEND_MESSAGE_TO_ALL == true then
			minetest.chat_send_all("The ban hammer has struck, wielded by "..puncher..", revoking shout from "..punched_player)
		end	
		minetest.chat_send_player(punched_player, puncher.." revoked privileges from you: shout")
	elseif mode == 4 then
		punched_player_privs["fly"] = nil
		minetest.set_player_privs(punched_player, punched_player_privs)
		minetest.log(puncher..' revoked (fly) privileges from '..punched_player)
		if SEND_MESSAGE_TO_ALL == true then
			minetest.chat_send_all("The ban hammer has struck, wielded by "..puncher..", revoking fly from "..punched_player)
		end	
		minetest.chat_send_player(punched_player, puncher.." revoked privileges from you: fly")
	elseif mode == 5 then
		punched_player_privs["noclip"] = nil
		minetest.set_player_privs(punched_player, punched_player_privs)
		minetest.log(puncher..' revoked (noclip) privileges from '..punched_player)
		if SEND_MESSAGE_TO_ALL == true then
			minetest.chat_send_all("The ban hammer has struck, wielded by "..puncher..", revoking noclip from "..punched_player)
		end	
		minetest.chat_send_player(punched_player, puncher.." revoked privileges from you: noclip")

	end
	return itemstack
end
	
minetest.register_craftitem("ban_hammer:hammer", {
	description = "Admin tool 1.0: Ban Hammer",
	inventory_image = "ban_hammer.png",
		
	on_use = function(itemstack, user, pointed_thing)
		local mode = 0
		ban_hammer_handler(itemstack, user, pointed_thing, mode)
		return itemstack
	end,
})

for i = 1, 5 do
	minetest.register_craftitem("ban_hammer:hammer"..i, {
		description = "Admin tool 1."..i..": Ban Hammer in Mode "..i,
		inventory_image = "ban_hammer.png^ban_tool_mode"..i..".png",
		wield_image = "ban_hammer.png",
		groups = {not_in_creative_inventory=1},
		
		on_use = function(itemstack, user, pointed_thing)
			local mode = i
			ban_hammer_handler(itemstack, user, pointed_thing, mode)
			return itemstack
		end,
		})
end

minetest.register_node(":testnodes:debug_block", {
    description = "Debug Block",
    tiles = {"debug.png"},
   groups = {cracky = 3, not_cuttable=1},
    on_construct = function(pos)
        local meta = minetest.get_meta(pos)
        meta:set_float("start_time", -1)
    end,
    on_punch = function(pos, node, puncher, pointed_thing)
        local meta = minetest.get_meta(pos)
        local start_time = meta:get_float("start_time")
        if start_time == -1 then
            meta:set_float("start_time", minetest.get_gametime())
        end
    end,
    on_dig = function(pos, node, digger)
        local meta = minetest.get_meta(pos)
        local start_time = meta:get_float("start_time")
        if start_time ~= -1 then
            local end_time = minetest.get_gametime()
            local dig_time = end_time - start_time
            minetest.chat_send_player(digger:get_player_name(), "It took you " .. dig_time .. " seconds to mine this block.")
        end
        minetest.remove_node(pos)
    end,
    after_dig_node = function(pos, oldnode, oldmetadata, digger)
        -- Clean up after the node is dug
        local meta = minetest.get_meta(pos)
        meta:set_float("start_time", -1)
    end,
})


minetest.register_craft({
    output = "soundstuff:appleblock",
    recipe = {
        {"default:apple", "default:apple", "default:apple"},
        {"default:apple", "default:apple", "default:apple"},
        {"default:apple", "default:apple", "default:apple"},
    }
})


minetest.register_craft({
    output = "default:oceanlamp",
    recipe = {
        {"", "default:water_source", ""},
        {"default:iron_lump", "xdecor:lantern", "default:iron_lump"},
        {"", "", ""}
    }
})

-- Register the crafting recipe if needed
minetest.register_craft({
    output = "dev:debug_block",
    recipe = {
        {"default:stone", "default:mese_crystal", "default:stone"},
        {"default:mese_crystal", "default:diamond", "default:mese_crystal"},
        {"default:stone", "default:mese_crystal", "default:stone"},
    }
})

-- print("[Mod] ban_hammer Loaded...")

minetest.register_node(":ugx:countdownblock", {
	description = "Animated countdown",
	tiles = {{
		name = "testtools_particle_vertical.png",
		animation = {
			type = "vertical_frames",
			aspect_w = 16,
			aspect_h = 16,
			length = 5,  -- Length of the entire animation in seconds (4 frames at 4 frames per second)
		},
	}},
	drawtype = "nodebox",
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}, -- Full block
		}
	},
	groups = {cracky = 3},
})

minetest.register_node(":soundstuff:KILLER", {
	description = "INSTANT DEATH BLOCK",
	tiles = {"kill.png"},
	groups = {unbreakable= 1},
  use_texture_alpha = "clip",
   drawtype = "allfaces",
  walkable=false,
	sounds = default.node_sound_ice_defaults(),
	damage_per_second = 65535,
})


minetest.register_node(":ugx:blink_light", {
	description = "blink light",
	tiles = {{
		name = "blink_light.png",
		animation = {
			type = "vertical_frames",
			aspect_w = 16,
			aspect_h = 16,
			length = 4.4,  -- Length of the entire animation in seconds (4 frames at 4 frames per second)
		},
	}},
	drawtype = "nodebox",
	paramtype = "light",
  light_source = 9,
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}, -- Full block
		}
	},
	groups = {cracky = 3},
})

-- Register the simple node
minetest.register_node(":terrain:silverware", {
   tiles = {"simplenode.png"},  -- You need to provide the texture "simplenode.png"
    groups = {plastic = 1},  -- Adjust groups as necessary
})

minetest.register_node(":ugx:fence_tree", {
	description = "tree Fence",
	drawtype = "fencelike",
	tiles = {"default_tree.png"},
	inventory_image = "default_tree.png^default_glass_detail.png^default_grass_4.png",
	wield_image = "default_tree.png^default_grass_4.png",
	paramtype = "light",
	selection_box = {
		type = "fixed",
		fixed = {-1/7, -1/2, -1/7, 1/7, 1/2, 1/7},
	},
	groups = {choppy=2,oddly_breakable_by_hand=2,flammable=2},
})

minetest.register_node(":ugx:glassold", {
	description = "Glass",
	drawtype = "glasslike",
	tiles = {"glass20.png"},

	inventory_image = minetest.inventorycube("glass20.png"),
	paramtype = "light",
	sunlight_propagates = true,
	groups = {cracky=3,oddly_breakable_by_hand=3, not_cuttable=1},
})

minetest.register_node(":ugx:glowblack", {
	tiles = {"tron.png"},
  light_source = 12,
	paramtype = "light",
	sunlight_propagates = true,
	groups = {cracky=3,oddly_breakable_by_hand=3, not_cuttable=1},
})

minetest.register_node(":ugx:glowwhite", {
	tiles = {"tronwhite.png"},
  light_source = 13,
	paramtype = "light",
	sunlight_propagates = true,
	groups = {cracky=3,oddly_breakable_by_hand=3, not_cuttable=1},
})



minetest.register_tool(":ugx:tool_cedipick", {
	description = "Super Pickaxe",
	inventory_image = "tutorial_tool_cedipick.png",
	tool_capabilities = {
		full_punch_interval = 0.1,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=0.1, [2]=0.1, [3]=0.1}, uses=20000, maxlevel=3},
       crumbly = {times={[1]= 0.4, [2]=0.2, [3]=0.0}, uses=2000, maxlevel=3},
       choppy = {times={[1]= 0.4, [2]=0.2, [3]=0.0}, uses=2000, maxlevel=3},  
		},
		damage_groups = {fleshy=15},
	},
})

minetest.register_tool(":default:alternatediamondpickaxe", {
	description = "Alternative Diamond Pickaxe",
	inventory_image = "apd.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]= 0.4, [2]=0.2, [3]=0.0}, uses=2000, maxlevel=3},
       crumbly = {times={[1]= 0.4, [2]=0.2, [3]=0.0}, uses=2000, maxlevel=3},
		},
		damage_groups = {fleshy=5},
	},
})

minetest.register_node(":ugx:torch", {
	description = "Ugx Torch",
	drawtype = "torchlike",
	--tiles = {"tutor_torch_on_floor.png", "default_torch_on_ceiling.png", "default_torch.png"},
	tiles = {
		{name="tutorial_torch_on_floor_animated.png", animation={type="vertical_frames", aspect_w=16, aspect_h=16, length=3.0}},
		{name="tutorial_torch_on_ceiling_animated.png", animation={type="vertical_frames", aspect_w=16, aspect_h=16, length=3.0}},
		{name="tutorial_torch_animated.png", animation={type="vertical_frames", aspect_w=16, aspect_h=16, length=3.0}}
	},
	inventory_image = "tutorial_torch_on_floor_animated.png",
	wield_image = "default_torch_on_floor.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	walkable = false,
	light_source = 14,
	selection_box = {
		type = "wallmounted",
		wall_top = {-0.1, 0.5-0.6, -0.1, 0.1, 0.5, 0.1},
		wall_bottom = {-0.1, -0.5, -0.1, 0.1, -0.5+0.6, 0.1},
		wall_side = {-0.5, -0.3, -0.1, -0.5+0.3, 0.3, 0.1},
	},
	groups = {choppy=2,dig_immediate=3,flammable=1,attached_node=1},
	legacy_wallmounted = true,
})


minetest.register_tool(":basetools:atomicbattleaxe", {
    description = "ATOMIC BATTLEAXE",
    inventory_image = "tutorial_atombattleaxe.png",
    tool_capabilities = {
        full_punch_interval = 5.0,
        max_drop_level = 5,
        groupcaps = {
            choppy = {
                times = {[1] = 0.1, [2] = 0.1, [3] = 0.1},
                uses = 20000,
                maxlevel = 10,
            },
        },
        damage_groups = {fleshy = 400},
    },
    wield_scale = {x = 2, y = 2, z = 1},  -- Adjust the wield scale as needed
})


minetest.register_node(":39r", {
    groups = { water_source = 1, liquid = 1, water = 1, flowing = 0, not_in_creative_inventory=1},

    tiles = { {
        name = "39r.png^[opacity:190",
        backface_culling = false,
    } },
    use_texture_alpha = "blend",
    drawtype = "liquid",
    paramtype = "light",
    waving = 99,

    walkable = false,
    liquid_move_physics = true,
    move_resistance = 10,
    drop = '',
    pointable = false,
    diggable = false,
    buildable_to = true,
    liquidtype = "source",
    liquid_viscosity = 9,
    liquid_renewable = false,
    liquid_range = 8,
    liquid_alternative_source = "39r",
    liquid_alternative_flowing = "39r_flowing",
    --_on_node_update = pmb_fluid_api.flow_maybe(0.5)
  })

  minetest.register_node(":39r_flowing", {
    groups = { water_flowing = 1, liquid = 1, water = 1, flowing = 1, not_in_creative_inventory=1},

    special_tiles = {
    {
        name = "39r.png^[opacity:190",
        backface_culling = false,
    },
    {
        name = "39r.png^[opacity:190",
        backface_culling = true,
    }
    },
    tiles = {"39r.png^[opacity:190"},
    use_texture_alpha = "blend",
    drawtype = "flowingliquid",

    paramtype = "light",
    paramtype2 = "flowingliquid",
    waving = 65535,

    walkable = false,
    liquid_move_physics = true,
    move_resistance = 10,
    pointable = false,
    diggable = false,
    drop = '',
    buildable_to = true,
    liquidtype = "flowing",
    liquid_viscosity = 9,
    liquid_renewable = false,
    liquid_range = 8,
    liquid_alternative_source = "39r",
    liquid_alternative_flowing = "39r_flowing",
  })

minetest.register_node(":caverealms:caverealms_glow_crystal_source", {
    description = "glow crystal Source",
    groups = { water_source = 1, liquid = 1, water = 1, flowing = 0,},

    tiles = { {
        name = "caverealms_glow_crystal.png",
        backface_culling = false,
    } },
    use_texture_alpha = "blend",
    drawtype = "liquid",
    paramtype = "light",
    waving = 3,

    walkable = false,
    liquid_move_physics = true,
    move_resistance = 1,
    pointable = false,
    light_source = 12,
    diggable = false,
    buildable_to = true,
    liquidtype = "source",
    liquid_viscosity = 0,
    liquid_renewable = false,
    liquid_range = 8,
    liquid_alternative_source = "caverealms:caverealms_glow_crystal_source",
    liquid_alternative_flowing = "caverealms:caverealms_glow_crystal_flowing",
    --_on_node_update = pmb_fluid_api.flow_maybe(0.5)
  })

  minetest.register_node(":caverealms:caverealms_glow_crystal_flowing", {
    description = "crystal Flowing",
    groups = { water_flowing = 1, liquid = 1, water = 1, flowing = 1},

    special_tiles = {
    {
        name = "caverealms_glow_crystal.png",
        backface_culling = false,
    },
    {
        name = "caverealms_glow_crystal.png",
        backface_culling = true,
    }
    },
    tiles = {"caverealms_glow_crystal.png"},
    use_texture_alpha = "blend",
    drawtype = "flowingliquid",

    paramtype = "light",
    paramtype2 = "flowingliquid",
    waving = 3,

    walkable = false,
    liquid_move_physics = true,
    move_resistance = 1,
   light_source = 12,
    pointable = false,
    diggable = false,
    buildable_to = true,
    liquidtype = "flowing",
    liquid_viscosity = 0,
    liquid_renewable = false,
    liquid_range = 8,
    liquid_alternative_source = "caverealms:caverealms_glow_crystal_source",
    liquid_alternative_flowing = "caverealms:caverealms_glow_crystal_flowing",
  })

minetest.register_node(":ugx:source", {
    description = "suspicious white fluid",
    groups = { water_source = 1, liquid = 1, water = 1, flowing = 0,},

    tiles = { {
        name = "xpanes_edge.png^[opacity:190",
        backface_culling = false,
    } },
    use_texture_alpha = "blend",
    drawtype = "liquid",
    paramtype = "light",
    waving = 65534,

    walkable = false,
    liquid_move_physics = true,
    move_resistance = 5,
    pointable = false,
    diggable = false,
    buildable_to = true,
    liquidtype = "source",
    liquid_viscosity = 5,
    liquid_renewable = false,
    liquid_range = 8,
    liquid_alternative_source = "ugx:source",
    liquid_alternative_flowing = "ugx:flowing",
    --_on_node_update = pmb_fluid_api.flow_maybe(0.5)
  })

  minetest.register_node(":ugx:flowing", {
    description = "strange substance  Flowing",
    groups = { water_flowing = 1, liquid = 1, water = 1, flowing = 1},

    special_tiles = {
    {
        name = "xpanes_edge.png^[opacity:190",
        backface_culling = false,
    },
    {
        name = "xpanes_edge.png^[opacity:190",
        backface_culling = true,
    }
    },
    tiles = {"xpanes_edge.png^[opacity:190"},
    use_texture_alpha = "blend",
    drawtype = "flowingliquid",

    paramtype = "light",
    paramtype2 = "flowingliquid",
    waving = 65534,

    walkable = false,
    liquid_move_physics = true,
    move_resistance = 5,
    pointable = false,
    diggable = false,
    buildable_to = true,
    liquidtype = "flowing",
    liquid_viscosity = 5,
    liquid_renewable = false,
    liquid_range = 8,
    liquid_alternative_source = "ugx:source",
    liquid_alternative_flowing = "ugx:flowing",
  })


-- ugx/init.lua

minetest.register_node(":testnodes:alpha_compositing", {
	description = ("Alpha Compositing Test Node") .. "\n" ..
		("A regular grid should be visible where each cell contains two " ..
		"texels with the same colour.") .. "\n" ..
		("Alpha compositing is gamma-incorrect for backwards compatibility."),
	drawtype = "glasslike",
	paramtype = "light",
	tiles = {"testnodes_alpha_compositing_bottom.png^"  ..
		"testnodes_alpha_compositing_top.png"},
	use_texture_alpha = "blend",
	groups = {dig_immediate = 3},
})



local nodebox_cable = {
	type = "connected",
	fixed          = {-2/16, -2/16, -2/16,  2/16,  2/16,  2/16},
	connect_front  = {-1/16, -1/16, -8/16,  1/16,  1/16, -2/16},
	connect_back   = {-1/16, -1/16,  2/16,  1/16,  1/16,  8/16},
	connect_left   = {-8/16, -1/16, -1/16, -2/16,  1/16,  1/16},
	connect_right  = { 2/16, -1/16, -1/16,  8/16,  1/16,  1/16},
	connect_bottom = {-1/16, -8/16, -1/16,  1/16, -2/16,  1/16},
	connect_top    = {-1/16,  2/16, -1/16,  1/16,  8/16,  1/16},
}



-- Wall-like nodebox that connects to 4 neighbors
minetest.register_node(":testnodes:nodebox_cable", {
	description = ("Connected cable Test Node (4 Side Wall)").."\n"..
		("Connects to 4 neighbors sideways"),
	tiles = {"testnodes_nodebox.png^[colorize:#F00:32"},
	groups = {connected_nodebox=1, dig_immediate=3},
	drawtype = "nodebox",
	paramtype = "light",
	connects_to = {"group:connected_nodebox"},
	connect_sides = {"front", "back", "left", "right"},
	node_box = nodebox_cable,
})

minetest.register_on_mods_loaded(function()
    for name, def in pairs(minetest.registered_nodes) do
        if string.find(name, "slab") or string.find(name, "stair") or string.find(name, "innerstair") then
            if def.groups then
                def.groups.not_in_creative_inventory = 1
            else
                def.groups = {not_in_creative_inventory = 1}
            end
            minetest.override_item(name, {groups = def.groups})
        end
    end
end)

minetest.register_node(":ugx:animated_sign", {
	description = "Animated Wall Sign",
	drawtype = "signlike",
	tiles = {{
		name = "testformspec_animation.png",
		animation = {
			type = "vertical_frames",
			aspect_w = 16,
			aspect_h = 16,
			length = 4,  -- Length of the entire animation in seconds (4 frames at 1 frame per second)
		},
	}},
	inventory_image = "testformspec_animation.png",
	wield_image = "testformspec_animation.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	walkable = false,
	is_ground_content = false,
	selection_box = {
		type = "wallmounted",
	},
	groups = {choppy = 2, oddly_breakable_by_hand = 2},
	legacy_wallmounted = true,
	sounds = default.node_sound_wood_defaults(),
})

-- Register a craft recipe for the animated sign if needed
minetest.register_craft({
	output = 'ugx:animated_sign',
	recipe = {
		{'default:stick'},
		{'default:woosbbbshzuaysgyehdd'},
	}
})


minetest.register_node(":testnodes:torchlike_wallmounted_rot", {
	description = ("Wallmounted Rotatable Torchlike Drawtype Test Node"),
	drawtype = "torchlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	wallmounted_rotate_vertical = true,
	tiles = {
		"testnodes_torchlike_floor.png^[colorize:#FFFF00:40",
		"testnodes_torchlike_ceiling.png^[colorize:#FFFF00:40",
		"testnodes_torchlike_wall.png^[colorize:#FFFF00:40",
	},


	walkable = false,
	sunlight_propagates = true,
	groups = { dig_immediate = 3 },
})


minetest.register_node(":testnodes:fill_positioning", {
	description = ("Fill Modifier Test Node") .. "\n" ..
		("The node should have the same look as " ..
		"testnodes:fill_positioning_reference. HOWEVER,  IF IT DOSENT THEN THAT MEANS THE END IS NEAR AND YOU ARE SCREWED"),
	drawtype = "glasslike",
	paramtype = "light",
	tiles = {"[fill:16x16:#ffffff^[fill:6x6:1,1:#00ffdc" ..
		"^[fill:6x6:1,9:#00ffdc^[fill:6x6:9,1:#00ffdc^[fill:6x6:9,9:#00ffdc"},
	groups = {dig_immediate = 3},
})

minetest.register_node(":testnodes:fill_positioning_reference", {
	description = ("Fill Modifier Test Node Reference"),
	drawtype = "glasslike",
	paramtype = "light",
	tiles = {"testnodes_fill_positioning_reference.png"},
	groups = {dig_immediate = 3},
})

-- Ensure the cobblebomb mod is loaded
if not minetest.get_modpath("cobble_bomb") then
	minetest.log("error", "[ban_hammer] Cobblebomb mod not found!")
	return
end

-- Register the Granatenwerfer tool
minetest.register_tool("ban_hammer:granatenwerfer", {
	description = "Granatenwerfer",
	inventory_image = "granatenwerfer.png",
	on_use = function(itemstack, player, pointed_thing)
		local player_pos = player:get_pos()
		local player_dir = player:get_look_dir()
		
		-- Calculate the initial position of the cobblebomb
		local spawn_pos = {
			x = player_pos.x + player_dir.x * 2,
			y = player_pos.y + 1.5 + player_dir.y * 2,
			z = player_pos.z + player_dir.z * 2,
		}

		-- Spawn the cobblebomb entity
		local cobblebomb = minetest.add_entity(spawn_pos, "cobble_bomb:cobblebomb")

		-- Propel the cobblebomb forward
		if cobblebomb then
			local velocity = vector.multiply(player_dir, 10)  -- Adjust the speed as needed
			cobblebomb:set_velocity(velocity)
			cobblebomb:set_acceleration({x = 0, y = -10, z = 0})  -- Gravity
		end

		-- Optional: Consume item durability or use ammunition
		itemstack:add_wear(65535 / 1000)  -- Example: 50 uses
		return itemstack
	end,
})

-- Optional: Register a craft recipe for the Granatenwerfer
minetest.register_craft({
	output = 'ban_hammer:granatenwerfer',
	recipe = {
		{'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
		{'', 'default:gwgsggaaggzvsmese_crystal', ''},
		{'', 'default:stick', ''},
	}
})

-- Register the slow cobblebomb thrower
minetest.register_node("ban_hammer:slow_cobblebomb_thrower", {
	tiles = {"1.png"},
  light_source = 2,
	is_ground_content = false,
	groups = {cracky = 3},
})



minetest.register_node(":testnodes:signlight14", {
	tiles = {"testnodes_light_14.png"},
  drawtype = "signlike",
  paramtype2 = "wallmounted",
  sunlight_propagates = true,
  paramtype = "light",
  light_source = 14,
  walkable = false,
	is_ground_content = false,
	groups = {dig_immediate=1},
})


-- Register the medium cobblebomb thrower
minetest.register_node("ban_hammer:medium_cobblebomb_thrower", {
	tiles = {"1.png"},
   light_source = 6,
	is_ground_content = false,
	groups = {cracky = 3},
})

-- Register the super fast cobblebomb thrower
minetest.register_node("ban_hammer:superfast_cobblebomb_thrower", {
	tiles = {"1.png"},
  light_source = 14,
	is_ground_content = false,
	groups = {cracky = 3},
})

-- ABM for slow cobblebomb thrower
minetest.register_abm({
	nodenames = {"ban_hammer:slow_cobblebomb_thrower"},
	interval = 3.0, -- Every 3 seconds
	chance = 1,
	action = function(pos)
		local obj = minetest.add_entity({x=pos.x, y=pos.y-1, z=pos.z}, "cobble_bomb:cobblebomb")
		if obj then
			obj:set_velocity({x=0, y=5, z=0}) -- Adjust velocity as needed
		end
	end,
})

-- ABM for medium cobblebomb thrower
minetest.register_abm({
	nodenames = {"ban_hammer:medium_cobblebomb_thrower"},
	interval = 2.0, -- Every 2 seconds
	chance = 1,
	action = function(pos)
		local obj = minetest.add_entity({x=pos.x, y=pos.y-1, z=pos.z}, "cobble_bomb:cobblebomb")
		if obj then
			obj:set_velocity({x=0, y=-10, z=0}) -- Adjust velocity as needed
		end
	end,
})

-- ABM for super fast cobblebomb thrower
minetest.register_abm({
	nodenames = {"ban_hammer:superfast_cobblebomb_thrower"},
	interval = 0.8, -- Every 1 second
	chance = 1,
	action = function(pos)
		local obj = minetest.add_entity({x=pos.x, y=pos.y-1, z=pos.z}, "cobble_bomb:cobblebomb")
		if obj then
			obj:set_velocity({x=0, y=-20, z=0}) -- Adjust velocity as needed
		end
	end,
})

minetest.register_tool("ban_hammer:special_sword", {
	description = "Special Sword",
	inventory_image = "2.png",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level = 1,
		groupcaps = {
			snappy = {times = {[1]=2.00, [2]=1.00, [3]=0.50}, uses = 100, maxlevel = 3},
		},
		damage_groups = {fleshy = 10},
	},
	on_use = function(itemstack, user, pointed_thing)
		if pointed_thing.type == "object" then
			local object = pointed_thing.ref
			if object then
				-- Add particles around the entity
				minetest.add_particlespawner({
					amount = 20,
					time = 0.5,
					minpos = {x=-0.5, y=0, z=-0.5},
					maxpos = {x=0.5, y=1.5, z=0.5},
					minvel = {x=-2, y=0, z=-2},
					maxvel = {x=2, y=3, z=2},
					minacc = {x=0, y=-9.8, z=0},
					maxacc = {x=0, y=-9.8, z=0},
					minexptime = 0.5,
					maxexptime = 1.0,
					minsize = 1,
					maxsize = 2,
					texture = "stripes.png",
					collisiondetection = true,
					collision_removal = false,
					attached = object,
				})
				-- Deal 10 damage to the entity
				object:punch(user, 1.0, {
					full_punch_interval = 1.0,
					damage_groups = {fleshy = 10},
				}, nil)
			end
		elseif pointed_thing.type == "node" then
			local pos = pointed_thing.under
			if pos then
				-- Add different particles around the node
				minetest.add_particlespawner({
					amount = 20,
					time = 0.5,
					minpos = {x=pos.x-0.5, y=pos.y, z=pos.z-0.5},
					maxpos = {x=pos.x+0.5, y=pos.y+1.5, z=pos.z+0.5},
					minvel = {x=-2, y=0, z=-2},
					maxvel = {x=2, y=3, z=2},
					minacc = {x=0, y=-9.8, z=0},
					maxacc = {x=0, y=-9.8, z=0},
					minexptime = 0.5,
					maxexptime = 1.0,
					minsize = 1,
					maxsize = 2,
					texture = "1.png",
					collisiondetection = true,
					collision_removal = false,
				})
			end
		end
		return itemstack
	end,
	on_place = function(itemstack, user, pointed_thing)
		-- Sword won't lose durability when used on nodes
		return itemstack
	end,
})
-- Register the particle textures


-- Register falling nodes
minetest.register_node(":testnodes:falling", {
	description = "Falling Node\nFalls down if no node below",
	tiles = {
		"testnodes_node.png",
		"testnodes_node.png",
		"testnodes_node_falling.png",
	},
	groups = {falling_node = 1, dig_immediate = 3},
})

minetest.register_node(":testnodes:falling_float", {
	description = "Falling+Floating Node\nFalls down if no node below, floats on liquids (liquidtype ~= 'none')",
	tiles = {
		"testnodes_node.png",
		"testnodes_node.png",
		"testnodes_node_falling.png",
	},
	groups = {falling_node = 1, float = 1, dig_immediate = 3},
	color = "cyan",
})

-- Register liquids
minetest.register_node(":testnodes:liquid_noswim", {
	description = "No-swim Liquid Source Node\nLiquid node, but swimming is disabled",
	liquidtype = "source",
	liquid_range = 1,
	liquid_viscosity = 0,
	liquid_alternative_flowing = "testnodes:liquidflowing_noswim",
	liquid_alternative_source = "testnodes:liquid_noswim",
	liquid_renewable = false,
	liquid_move_physics = false,
	groups = {dig_immediate = 3},
	walkable = false,
	drawtype = "liquid",
	tiles = {"testnodes_liquidsource.png^[colorize:#FF00FF:127"},
	special_tiles = {
		{name = "testnodes_liquidsource.png^[colorize:#FF00FF:127", backface_culling = false},
		{name = "testnodes_liquidsource.png^[colorize:#FF00FF:127", backface_culling = true},
	},
	use_texture_alpha = "blend",
	paramtype = "light",
	pointable = false,
	liquids_pointable = true,
	buildable_to = true,
	is_ground_content = false,
	post_effect_color = {a = 70, r = 255, g = 200, b = 200},
})

minetest.register_node(":testnodes:liquidflowing_noswim", {
	description = "No-swim Flowing Liquid Node\nLiquid node, but swimming is disabled",
	liquidtype = "flowing",
	liquid_range = 1,
	liquid_viscosity = 0,
	liquid_alternative_flowing = "testnodes:liquidflowing_noswim",
	liquid_alternative_source = "testnodes:liquid_noswim",
	liquid_renewable = false,
	liquid_move_physics = false,
	groups = {dig_immediate = 3},
	walkable = false,
	drawtype = "flowingliquid",
	tiles = {"testnodes_liquidflowing.png^[colorize:#FF00FF:127"},
	special_tiles = {
		{name = "testnodes_liquidflowing.png^[colorize:#FF00FF:127", backface_culling = false},
		{name = "testnodes_liquidflowing.png^[colorize:#FF00FF:127", backface_culling = false},
	},
	use_texture_alpha = "blend",
	paramtype = "light",
	paramtype2 = "flowingliquid",
	pointable = false,
	liquids_pointable = true,
	buildable_to = true,
	is_ground_content = false,
	post_effect_color = {a = 70, r = 255, g = 200, b = 200},
})

minetest.register_node(":testnodes:liquid_nodescend", {
	description = "No-descending Liquid Source Node",
	liquidtype = "source",
	liquid_range = 0,
	liquid_viscosity = 0,
	liquid_alternative_flowing = "testnodes:liquidflowing_nodescend",
	liquid_alternative_source = "testnodes:liquid_nodescend",
	liquid_renewable = false,
	groups = {disable_descend = 1, dig_immediate = 3},
	walkable = false,
	drawtype = "liquid",
	tiles = {"testnodes_liquidsource.png^[colorize:#FFFF00:127"},
	special_tiles = {
		{name = "testnodes_liquidsource.png^[colorize:#FFFF00:127", backface_culling = false},
		{name = "testnodes_liquidsource.png^[colorize:#FFFF00:127", backface_culling = true},
	},
	use_texture_alpha = "blend",
	paramtype = "light",
	pointable = false,
	liquids_pointable = true,
	is_ground_content = false,
	post_effect_color = {a = 70, r = 255, g = 255, b = 200},
})

minetest.register_node(":testnodes:liquidflowing_nodescend", {
	description = "No-descending Flowing Liquid Node",
	liquidtype = "flowing",
	liquid_range = 1,
	liquid_viscosity = 0,
	liquid_alternative_flowing = "testnodes:liquidflowing_nodescend",
	liquid_alternative_source = "testnodes:liquid_nodescend",
	liquid_renewable = false,
	groups = {disable_descend = 1, dig_immediate = 3},
	walkable = false,
	drawtype = "flowingliquid",
	tiles = {"testnodes_liquidflowing.png^[colorize:#FFFF00:127"},
	special_tiles = {
		{name = "testnodes_liquidflowing.png^[colorize:#FFFF00:127", backface_culling = false},
		{name = "testnodes_liquidflowing.png^[colorize:#FFFF00:127", backface_culling = false},
	},
	use_texture_alpha = "blend",
	paramtype = "light",
	paramtype2 = "flowingliquid",
	pointable = false,
	liquids_pointable = true,
	is_ground_content = false,
	post_effect_color = {a = 70, r = 255, g = 255, b = 200},
})

-- Move resistance nodes (various resistance levels)
for r = 0, 7 do
	if r > 0 then
		minetest.register_node(":testnodes:move_resistance" .. r, {
			description = "Move-resistant Node (" .. r .. ")\nReduces movement speed",
			walkable = false,
			move_resistance = r,
			drawtype = "glasslike",
			paramtype = "light",
			sunlight_propagates = true,
			tiles = {"testnodes_move_resistance.png"},
			is_ground_content = false,
			groups = {dig_immediate = 3},
			color = {b = 0, g = 255, r = math.floor((r / 7) * 255), a = 255},
		})
	end

	local mdesc, mcolor
	if r == 0 then
		mdesc = "Liquidlike Movement Node\nSwimmable (no move resistance)"
		mcolor = {b = 255, g = 255, r = 128}
	else
		mdesc = "Move-resistant Node (" .. r .. "), liquidlike\nReduces movement speed; swimmable"
		mcolor = {b = 255, g = 0, r = math.floor((r / 7) * 255), a = 255}
	end

	minetest.register_node(":testnodes:move_resistance_liquidlike" .. r, {
		description = mdesc,
		walkable = false,
		move_resistance = r,
		liquid_move_physics = true,
		drawtype = "glasslike",
		paramtype = "light",
		sunlight_propagates = true,
		tiles = {"testnodes_move_resistance.png"},
		is_ground_content = false,
		groups = {dig_immediate = 3},
		color = mcolor,
	})
end


-- Register the cracked glass node with an overlay of cracked glass
minetest.register_node(":default:cracked_glass", {
	description = "Cracked Glass",
	drawtype = "glasslike",
	tiles = {"default_glass.png^cracked_glass.png"},
	paramtype = "light",
	sunlight_propagates = true,
	is_ground_content = false,
  drop = 'default:glass',
	groups = {cracky = 3, oddly_breakable_by_hand = 3, not_cuttable=1},
	sounds = default.node_sound_glass_defaults(),
})

-- Function to swap default glass to cracked glass
local function swap_to_cracked_glass(pos, node, player, pointed_thing)
	local wielded_item = player:get_wielded_item()
	local wielded_item_name = wielded_item:get_name()

	-- Check if the wielded item is a pickaxe
	if minetest.get_item_group(wielded_item_name, "stone") > 0 then
		-- Get the node's name
		local node_name = minetest.get_node(pos).name

		-- Check if the node is default glass
		if node_name == "default:glass" then
			-- Set the node to cracked glass
			minetest.set_node(pos, {name = "default:cracked_glass"})
		end
	end
end

-- Register the on_punchnode callback to handle the node swap
minetest.register_on_punchnode(function(pos, node, player, pointed_thing)
	if player and not player:is_player() then
		return
	end
	swap_to_cracked_glass(pos, node, player, pointed_thing)
end)


-----------------------------------------------------------------------------------------------
print("[Mod] "..title.." ["..version.."] ["..mname.."] Loaded...")
-----------------------------------------------------------------------------------------------
