Ban Hammer
==========

Mod for Minetest that adds a hammer which bans any player that is punched with it.

Version: 0.2.1

License of code: GPLv3 
See LICENSE for full legal text.

License of textures: CC-BY-SA 4.0
See textures/LICENSE for full legal text.

